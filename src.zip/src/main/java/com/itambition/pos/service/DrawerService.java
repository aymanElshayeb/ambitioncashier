package com.itambition.pos.service;

import org.springframework.stereotype.Service;

@Service

public class DrawerService {
}
