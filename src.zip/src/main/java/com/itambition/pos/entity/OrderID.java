package com.itambition.pos.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
//@NoArgsConstructor
//@AllArgsConstructor
@Builder
@Embeddable
public class OrderID implements Serializable {
    private int order_id;
    private int item_id;

    public OrderID() {
    }

    public OrderID(int order_id, int item_id) {
        this.order_id = order_id;
        this.item_id = item_id;
    }
    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public int getItem_id() {
        return item_id;
    }

    public void setItem_id(int item_id) {
        this.item_id = item_id;
    }
}
