package com.itambition.pos.repository;
import com.itambition.pos.entity.SubCategoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SubCategoryRepo extends JpaRepository<SubCategoryEntity,Integer>{

}
