package com.itambition.pos.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController

public class DrawerController {
}
